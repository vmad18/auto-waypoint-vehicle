#ifndef GPSNAVIGATION_LOCVEC_H
#define GPSNAVIGATION_LOCVEC_H

#endif //GPSNAVIGATION_LOCVEC_H

class LocVec{
    private:
        double lattiude, longitude;
        bool set=false;
    public:
        LocVec(double lat, double lng);
        LocVec();
        double getLat();
        double getLng();
        void setLoc(double lat, double lng);
        LocVec add(LocVec lv);
        LocVec subtract(LocVec lv);
        double direction(); 
        bool isSet(); 
        void setV();
};
