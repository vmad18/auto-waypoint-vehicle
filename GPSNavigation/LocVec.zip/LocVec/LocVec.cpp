#include <LocVec.h>
#include <Arduino.h>
LocVec::LocVec(double lat, double lng) {
    this->lattiude = lat;
    this->longitude = lng;
}

LocVec::LocVec() {
    this->lattiude = 0;
    this->longitude = 0;
}

void LocVec::setLoc(double lat, double lng) {
    this->lattiude = lat;
    this->longitude = lng;
}

double LocVec::getLat() {
    return this->lattiude;
}

double LocVec::getLng() {
    return this->longitude;
}

LocVec LocVec::add(LocVec lv) {
    return LocVec(this->lattiude + lv.getLat(), this->longitude + lv.getLng());
}

LocVec LocVec::subtract(LocVec lv) {
    return LocVec(this->lattiude - lv.getLat(), this->longitude - lv.getLng());
}

double LocVec::direction() {
    return atan2(this->lattiude, this->longitude);
}

bool LocVec::isSet(){
  return this->set; 
}

void LocVec::setV(){
  this->set = true;
}
